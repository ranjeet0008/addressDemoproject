package com.address.demo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
 * @author Ranjeet This class will load spring context and is the Entry point for
 *         the application, it will boot up the spring application
 *
 */

@SpringBootApplication
public class AddressDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddressDemoApplication.class, args);
	}

}
