package com.address.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.address.demo.entity.Address;

/**
 * 
 * @author Ranjeet This is an interface to define spring JPA function by
 *         extending JpaRepository defined only one function findByCountryCode
 *         it will retrieve all the records from address_table for a given
 *         country code
 */

@Repository
public interface AddressRepository extends JpaRepository<Address, Long> {
	List<Address> findByCountryCode(String countryCode);
	List<Address> findByState(String state);

}
