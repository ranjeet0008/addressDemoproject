INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (100,'317','Madison Point',NULL,'OFallon','MO','USA');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (200,'470','Cincinnati',NULL,'Cincinnati','OHIO','USA');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (300,'500','vancouver',NULL,'vancouver','CA','CN');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (700,'317','Prairie Point',NULL,'OFallon','MO','USA');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (101,'317','Prairie Point',NULL,'OFallon','MO','USA');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (201,'470','Chesterfield',NULL,'Chesterfield','MO','USA');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (301,'500','Toronto ',NULL,'Toronto ','CA','CN');
INSERT INTO address_table (`id`,`street_no`,`address_line_1`,`address_line_2`,`city`,`state`,`country_code`) VALUES (701,'317','Harperpoint drive',NULL,'Motogomery','OHIO','USA');
