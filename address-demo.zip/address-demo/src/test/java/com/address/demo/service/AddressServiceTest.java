package com.address.demo.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import com.address.demo.entity.Address;

class AddressServiceTest {

	@Test
	public void testFindByCountryCodelUSA() {
		Address add = new Address();
		add.setId(800);
		add.setCountryCode("USA");
		List<Address> addressList = new ArrayList<>();
		addressList.add(add);
		AddressService addressService = mock(AddressService.class);
		when(addressService.findByCountryCode("USA")).thenReturn(addressList);
		List<Address> outList = addressService.findByCountryCode("USA");
		assertNotNull(outList);

	}

}
